# Svatební sada pro marienbad.com — jak to nasadit

Obsah tohoto archivu kopíruje strukturu repa https://github.com/veritasderman-rgb/marienbad

```
public/images/library/wedding/   20 fotek (jpg + webp + 800w webp) = 60 souborů
docs/weddings/ZADANI-svatby.md   zadání landing page + magazínového článku
docs/weddings/IMAGE-MANIFEST.md  názvy, rozměry, alt texty cs/de/en/ru, varování
```

## Postup

```bash
cd ~/…/marienbad
git checkout -b feat/weddings
# rozbal archiv do kořene repa (přepíše nic, jen přidává)
unzip -o ~/Downloads/marienbad-wedding-drop.zip -d .
pnpm images        # POVINNÉ — přegeneruje src/data/webp-manifest.json
pnpm build         # kontrola, že nic nespadlo
git add public/images/library/wedding docs/weddings src/data/webp-manifest.json
git commit -m "feat(weddings): add wedding photo library set + implementation brief"
git push -u origin feat/weddings
```

Bez `pnpm images` sada nebude v manifestu a `<Pic>` spadne zpět na neoptimalizovaný `<img>`.

## Než se to publikuje

V `docs/weddings/ZADANI-svatby.md` je sekce **D. Ověřit před publikací** — souhlasy
vyobrazených osob, kredit fotografa, rozpor v kapacitách sálů a otázka, kdo reálně
pronajímá kolonádu a Zpívající fontánu. Fotky samotné se dají commitnout hned,
publikace na web až po tomhle.
