# Svatební sada — 2. dávka (13 fotek „getting ready")

Přidává se do stejné složky jako první dávka, nic nepřepisuje.

```
public/images/library/wedding/         13 fotek (jpg + webp + 800w) = 39 souborů
docs/weddings/IMAGE-MANIFEST-vv.md     popisy, alt texty cs/de/en/ru, kam co patří
```

## Postup

```bash
cd ~/…/marienbad
unzip -o ~/Downloads/marienbad-wedding-drop-2.zip -d .
pnpm images        # POVINNÉ znovu — do manifestu se musí dostat i nová dávka
pnpm build
git add public/images/library/wedding docs/weddings src/data/webp-manifest.json
git commit -m "feat(weddings): add getting-ready photo set (13)"
```

Sada `library/wedding/` má po nasazení **33 fotek**.

## Pozor

Fotky jsou od **třetího svatebního páru** (jiná nevěsta než v první dávce) a na dvou
snímcích z baru jsou hosté a zaměstnankyně hotelu. Souhlasy je potřeba od všech tří
párů zvlášť — detail v `IMAGE-MANIFEST-vv.md`.
