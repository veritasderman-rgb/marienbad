/**
 * Fotobanka hotelů — přístup k WebP variantám vygenerovaným z archivu
 * `MARIENBAD_MARKETING` (viz `_web-export/README.md`).
 *
 * Pro každou fotku existují tři soubory:
 *   `<base>-1600.webp`  galerie / lightbox / hero
 *   `<base>-800.webp`   běžné dlaždice
 *   `<base>-400.webp`   náhledy v mřížce
 *
 * Zdroj dat: `src/data/hotel-photos.json` (generováno skriptem, needituje se ručně).
 */
import data from '@/data/hotel-photos.json'

export const PHOTO_CATEGORIES = [
  'highlights',
  'exterior',
  'rooms',
  'interior',
  'dining',
  'pool',
  'spa',
  'mice',
  'other',
] as const

export type PhotoCategory = (typeof PHOTO_CATEGORIES)[number]

export interface HotelPhoto {
  id: string
  category: PhotoCategory
  /** Cesta bez přípony a bez šířky, např. `/images/hotels/butterfly/rooms/dbl-superior` */
  base: string
  /** Rozměry zdrojové fotky (pro poměr stran) */
  w: number
  h: number
  orientation: 'landscape' | 'portrait'
}

const byHotel = data as unknown as Record<string, HotelPhoto[]>

/** Největší vygenerovaná varianta. Musí odpovídat SIZES v konverzním skriptu. */
const MAX_WIDTH = 1600

export function hotelPhotos(slug: string): HotelPhoto[] {
  return byHotel[slug] ?? []
}

export function hasPhotos(slug: string): boolean {
  return (byHotel[slug]?.length ?? 0) > 0
}

/** Fotky jedné kategorie, případně omezené na `limit` kusů. */
export function photosOf(slug: string, category: PhotoCategory, limit?: number): HotelPhoto[] {
  const list = hotelPhotos(slug).filter((p) => p.category === category)
  return typeof limit === 'number' ? list.slice(0, limit) : list
}

/**
 * Fotky z první kategorie, která něco má — v pořadí podle `preferred`.
 * Používá se tam, kde sekce potřebuje ilustraci, ale ne každý hotel má
 * v archivu stejné složky.
 */
export function firstAvailable(slug: string, preferred: PhotoCategory[], limit: number): HotelPhoto[] {
  for (const cat of preferred) {
    const list = photosOf(slug, cat, limit)
    if (list.length > 0) return list
  }
  return []
}

/** Kategorie, které mají u daného hotelu alespoň jednu fotku (v pořadí PHOTO_CATEGORIES). */
export function categoriesOf(slug: string): PhotoCategory[] {
  const present = new Set(hotelPhotos(slug).map((p) => p.category))
  return PHOTO_CATEGORIES.filter((c) => present.has(c))
}

/** Hero fotka: nejlepší dostupná krajinná fotka (highlights → exterior → interior). */
export function heroPhoto(slug: string): HotelPhoto | undefined {
  const pool = hotelPhotos(slug)
  const preferred: PhotoCategory[] = ['highlights', 'exterior', 'interior', 'rooms']
  for (const cat of preferred) {
    const found = pool.find((p) => p.category === cat && p.orientation === 'landscape')
    if (found) return found
  }
  return pool[0]
}

export function srcset(photo: HotelPhoto): string {
  return [400, 800, 1600]
    .filter((w) => w <= Math.max(photo.w, 400))
    .map((w) => `${photo.base}-${w}.webp ${w}w`)
    .join(', ')
}

/** Rozměry největší varianty — do width/height atributů, aby stránka neposkakovala. */
export function displaySize(photo: HotelPhoto): { width: number; height: number } {
  const width = Math.min(photo.w, MAX_WIDTH)
  return { width, height: Math.round((photo.h * width) / photo.w) }
}

export function largest(photo: HotelPhoto): string {
  return `${photo.base}-${Math.min(photo.w, MAX_WIDTH) > 800 ? 1600 : 800}.webp`
}
